import LeadForm from "./components/LeadForm";
import ProjectCatalog from "./components/ProjectCatalog";

type Advantage = {
  id: number;
  title: string;
  description: string;
  icon: string;
};

type WorkStep = {
  id: number;
  title: string;
  description: string;
};

type FAQ = {
  id: number;
  question: string;
  answer: string;
};

type Review = {
  id: number;
  author_name: string;
  city: string;
  text: string;
  project_name: string;
  rating: number;
};

type HomepageContent = {
  advantages: Advantage[];
  work_steps: WorkStep[];
  faqs: FAQ[];
  reviews: Review[];
};

type LandingPage = {
  id: number;
  title: string;
  slug: string;
  h1: string;
  page_type: string;
};

async function getHomepageContent(): Promise<HomepageContent> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL;

  const response = await fetch(`${apiUrl}/homepage/`, {
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error("Не удалось загрузить контент главной страницы");
  }

  return response.json();
}

async function getLandingPages(): Promise<LandingPage[]> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL;

  const response = await fetch(`${apiUrl}/landing-pages/`, {
    cache: "no-store",
  });

  if (!response.ok) {
    return [];
  }

  return response.json();
}

export default async function HomePage() {
  const [homepageContent, landingPages] = await Promise.all([
    getHomepageContent(),
    getLandingPages(),
  ]);

  return (
    <main>
      <section className="hero">
        <div className="container">
          <p className="eyebrow">Дома, бани и гаражи из бруса</p>

          <h1>Строительство из дерева с собственного производства</h1>

          <p className="heroText">
            Проекты домов, бань и гаражей с понятными комплектациями,
            сроками и ценами. Работаем по региону и организуем строительство
            по России.
          </p>

          <div className="heroActions">
            <a href="#projects" className="buttonPrimary">
              Смотреть проекты
            </a>
            <a href="#lead-form" className="buttonSecondary">
              Рассчитать стоимость
            </a>
          </div>
        </div>
      </section>

      {landingPages.length > 0 && (
        <section className="container section">
          <div className="sectionHeader">
            <p className="eyebrow">Популярные направления</p>
            <h2>Что чаще всего выбирают заказчики</h2>
          </div>

          <div className="seoLinkGrid">
            {landingPages.map((page) => (
              <a className="seoLinkCard" href={`/${page.slug}`} key={page.id}>
                <span>{page.page_type}</span>
                <strong>{page.h1 || page.title}</strong>
              </a>
            ))}
          </div>
        </section>
      )}

      {homepageContent.advantages.length > 0 && (
        <section className="container section">
          <div className="sectionHeader">
            <p className="eyebrow">Почему выбирают нас</p>
            <h2>Собственное производство и понятная комплектация</h2>
          </div>

          <div className="advantageGrid">
            {homepageContent.advantages.map((advantage) => (
              <article className="infoCard" key={advantage.id}>
                <div className="iconBadge">{advantage.icon || "✓"}</div>
                <h3>{advantage.title}</h3>
                <p>{advantage.description}</p>
              </article>
            ))}
          </div>
        </section>
      )}

      <ProjectCatalog
        showFilters={false}
        maxItems={6}
        eyebrow="Каталог"
        title="Популярные проекты"
        description="Несколько популярных проектов домов, бань и гаражей. Полный каталог удобнее смотреть на тематических страницах."
      />

      {homepageContent.work_steps.length > 0 && (
        <section className="container section">
          <div className="sectionHeader">
            <p className="eyebrow">Как мы работаем</p>
            <h2>Этапы строительства</h2>
          </div>

          <div className="stepList">
            {homepageContent.work_steps.map((step, index) => (
              <article className="stepCard" key={step.id}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {homepageContent.reviews.length > 0 && (
        <section className="container section">
          <div className="sectionHeader">
            <p className="eyebrow">Отзывы</p>
            <h2>Что говорят клиенты</h2>
          </div>

          <div className="reviewGrid">
            {homepageContent.reviews.map((review) => (
              <article className="infoCard" key={review.id}>
                <div className="reviewRating">{"★".repeat(review.rating)}</div>

                <p>{review.text}</p>

                <strong>{review.author_name}</strong>

                {(review.city || review.project_name) && (
                  <span className="reviewMeta">
                    {[review.city, review.project_name]
                      .filter(Boolean)
                      .join(" · ")}
                  </span>
                )}
              </article>
            ))}
          </div>
        </section>
      )}

      {homepageContent.faqs.length > 0 && (
        <section className="container section">
          <div className="sectionHeader">
            <p className="eyebrow">FAQ</p>
            <h2>Частые вопросы</h2>
          </div>

          <div className="faqList">
            {homepageContent.faqs.map((faq) => (
              <details className="faqItem" key={faq.id}>
                <summary>{faq.question}</summary>
                <p>{faq.answer}</p>
              </details>
            ))}
          </div>
        </section>
      )}

      <section className="container section" id="lead-form">
        <LeadForm title="Получить консультацию" source="callback" />
      </section>
    </main>
  );
}